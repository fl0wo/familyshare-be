const { validateChangePassword } = require('./validateChangePassword')
const { validateUpdateProfile } = require('./validateUpdateProfile')

module.exports = {
  validateChangePassword,
  validateUpdateProfile
}
